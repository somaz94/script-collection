#!/usr/bin/env bash

recipient="support@iorchard.co.kr"
STATE=$(kubectl get node |grep 'NotReady' |awk '{print $2}')
hostname=$(kubectl get node |grep 'NotReady' |awk '{print $1}')
name=$(hostname)
 
if [ "${STATE}" == "NotReady" ];then
    touch /home/clex/monthly_maintenance/send_mail
    echo "${hostname}" "${STATE}" >> /home/clex/monthly_maintenance/send_mail
    #echo "${STATE}" >> /home/clex/monthly_maintenance/send_mail
    #sudo cat /home/clex/monthly_maintenance/send_mail | sudo /usr/sbin/sendmail -s "Node NotReady"  ${recipient}
    sudo cat /home/clex/monthly_maintenance/send_mail | sudo mail -s "$(hostname) Node NotReady" ${recipient}
    sudo rm -f /home/clex/monthly_maintenance/send_mail
    exit 0
    echo ""
    exit 0
fi
